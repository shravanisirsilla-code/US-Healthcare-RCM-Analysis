// Small enhancement: highlight the current section link while scrolling.
const sections = document.querySelectorAll('main section[id]');
const links = document.querySelectorAll('.nav-links a');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        links.forEach((link) => {
          link.style.color = link.getAttribute('href') === `#${entry.target.id}` ? '#ffffff' : '';
        });
      }
    });
  }, { rootMargin: '-25% 0px -65% 0px' });
  sections.forEach((section) => observer.observe(section));
}
