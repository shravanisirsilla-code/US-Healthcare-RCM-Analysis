# US Healthcare – Medical Billing & RCM Analysis

A GitHub Pages portfolio website for an Excel-based educational project using 1,000 simulated healthcare claims.

## Files
- `index.html` – website content
- `style.css` – responsive styling
- `script.js` – small navigation enhancement
- `assets/rcm-dashboard.png` – dashboard screenshot
- `US_Healthcare_RCM_Analysis.xlsx` – upload your reviewed workbook to the repository root for the download link to work

## Publish with GitHub Pages
1. Create a public GitHub repository.
2. Upload all website files and the reviewed workbook.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then save.
6. Wait for the published website URL to appear in the Pages section.

## Data note
This is a simulated learning project. Do not publish real patient information or protected health information (PHI).
